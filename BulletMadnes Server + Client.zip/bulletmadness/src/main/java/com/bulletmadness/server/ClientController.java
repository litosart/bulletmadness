package com.bulletmadness.server;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@RequestMapping("/players")
public class ClientController {

	private Map<String, Client> clientsConected = new ConcurrentHashMap<>();
	private Timer timeout = new Timer();
	
	@GetMapping
	public Map<String, Client> getConectedClients() {

		return clientsConected;
	}
	
	@GetMapping("/connected")
	public int connectedClients() {
		return clientsConected.size();
	}
	
	@GetMapping("/playerNames")
	public String[] namesClients() {
		String[] res = new String[10];
		ArrayList<Client> clients = new ArrayList<Client>(clientsConected.values());
		for(int i=0; i<res.length; i++)
		{
			if(clients.size() > i)
			{
				res[i] = clients.get(i).getName();
			}
		}
		
		return res;
	}

	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public Client addClient(@RequestBody Client client) {
		
		client.setId(UUID.randomUUID().toString());
		clientsConected.put(client.getId(), client);
		SetTimeoutCheckLoop(client,1500);
		
		return client;
	}
	
	@PostMapping("/name")
	@ResponseStatus(HttpStatus.CREATED)
	public void setClientName(@RequestBody Client client) {
		clientsConected.get(client.getId()).setName(client.getName());
	}
	
	public void SetTimeoutCheckLoop(Client client,long maxPing) {
		timeout.schedule(new TimerTask() {
			@Override
			public void run() {
				if(!TryToTimeout(client)) {
					SetTimeoutCheckLoop(client,maxPing);
				}
			}
		}, maxPing);
	}
	
	public boolean TryToTimeout(Client client) {
		if(!client.isConnected()) {
			clientsConected.remove(client.getId());
			return true;
		}
		client.setConnected(false);
		return false;
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<Client> updateClient(@PathVariable String id, @RequestBody Client updatedClient) {

		Client savedClient = clientsConected.get(id);
		
		if (savedClient != null) {
			
			updatedClient.setId(id);
			clientsConected.get(id).setConnected(true);

			return new ResponseEntity<>(updatedClient, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Client> deleteClient(@PathVariable String id) {

		Client savedClient = clientsConected.get(id);

		if (savedClient != null) {
			clientsConected.remove(savedClient.getId());
			return new ResponseEntity<>(savedClient, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
}
