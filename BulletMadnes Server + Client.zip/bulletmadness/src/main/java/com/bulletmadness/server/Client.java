package com.bulletmadness.server;

public class Client {
	
	private boolean connected;
	private String id;
	private String name;
	
	public Client () {}
	
	public void setId(String newId) {
		id = newId;
	}

	public String getId() {
		return id;
	}
	
	public String getName()
	{
		return name;
	}

	public boolean isConnected() {
		return connected;
	}

	public void setConnected(boolean connected) {
		this.connected = connected;
	}
	
	public void setName(String n)
	{
		name = n;
	}

}
