package com.bulletmadness.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

@SpringBootApplication
@EnableWebSocket
public class BulletmadnessApplication implements WebSocketConfigurer {

	public static void main(String[] args) {
		SpringApplication.run(BulletmadnessApplication.class, args);
	}

	@Override
	public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
		registry.addHandler(createGameplayHandler(), "/gameplay").setAllowedOrigins("*");
		registry.addHandler(createEnemiesHandler(), "/enemies").setAllowedOrigins("*");
		registry.addHandler(createBeamHandler(), "/beam").setAllowedOrigins("*");
	}
	
	@Bean
	public GameplayHandler createGameplayHandler() {
		return new GameplayHandler();
	}
	
	@Bean
	public EnemiesHandler createEnemiesHandler() {
		return new EnemiesHandler();
	}
	
	@Bean
	public BeamHandler createBeamHandler() {
		return new BeamHandler();
	}

}
