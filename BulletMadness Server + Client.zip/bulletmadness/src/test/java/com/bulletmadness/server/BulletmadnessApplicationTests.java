package com.bulletmadness.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BulletmadnessApplicationTests {

	@Test
	void contextLoads() {
	}

}
