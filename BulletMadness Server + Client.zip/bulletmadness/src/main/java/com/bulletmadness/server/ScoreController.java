package com.bulletmadness.server;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

import javax.annotation.PostConstruct;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.reflect.TypeToken;

@RestController
@CrossOrigin
@RequestMapping("/leaderboard")
public class ScoreController {

	private List<Score> leaderboard = new ArrayList<Score>();

	@PostConstruct
	public void init() {
		readLeaderboardFile();
		leaderboard = new ArrayList<Score>();
	}

	@GetMapping
	public List<Score> getLeaderboard() {
		return leaderboard;
	}

	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public Score addScore(@RequestBody Score score) {

		score.setId(UUID.randomUUID().toString());
		leaderboard.add(score);
		// leaderboard.sort(Comparator.comparingLong(Score::getScoreNumber));
		leaderboard.sort(new Comparator<Score>() {
			public int compare(Score o1, Score o2) {
				return o2.getScoreNumber() - o1.getScoreNumber();
			}
		});
		
		writeLeaderboardFile();
		
		return score;
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Score> deleteScore(@PathVariable String id) {

		int i = 0;
		while (i < leaderboard.size()) {
			if (leaderboard.get(i).getId().toString().compareTo(id) == 0) {

				Score savedScore = leaderboard.get(i);
				leaderboard.remove(i);
				return new ResponseEntity<>(savedScore, HttpStatus.OK);
			}
			i++;
		}
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
	private void readLeaderboardFile() {
		Gson gson = new Gson();

		Reader reader = null;

		try {
			reader = Files.newBufferedReader(Paths.get("Leaderboard.txt"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		leaderboard = gson.fromJson(reader, new TypeToken<List<Score>>() {
		}.getType());

		try {
			reader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void writeLeaderboardFile() {
		try {
			Gson gson = new Gson();
			FileWriter outputFile = new FileWriter(new File("Leaderboard.txt"));
			gson.toJson(leaderboard, outputFile);
			outputFile.close();
		} catch (JsonIOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
