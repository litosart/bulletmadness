package com.bulletmadness.server;

public class Score {
	
	private String playerName;
	private String id;
	private int scoreNumber;
	
	public void setId(String newId) {
		id = newId;
	}

	public String getId() {
		return id;
	}

	public int getScoreNumber() {
		return scoreNumber;
	}

	public void setScoreNumber(int scoreNumber) {
		this.scoreNumber = scoreNumber;
	}

	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
}
